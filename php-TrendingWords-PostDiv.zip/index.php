<!DOCTYPE html>
<html lang="en">

    <head>
        <title>ProjectBigBreakfast | Homepage</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/main.css" rel="stylesheet">
    </head>

    <body>

        <div id="wrapper" expanded-left="false" expanded-right="false">
            
            <nav id="navbar" class="navbar navbar-inverse navbar-fixed-top device-fixed-height">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <div  class="navbar-brand">
                            <a href="#" class="menu-toggle nav navbar-nav glyphicon glyphicon-align-justify btn-menu toggle" data-toggle="collapse-slide-left" data-target="#sidebar-left-wrapper" aria-expanded="true">
                                <i class="fa fa-bars"></i>
                            </a>
                            <a id="title" href="#">ProjectBigBreakfast</a>
                        </div> <!-- /navbar-brand -->
                        <a href="#" class="menu-toggle nav navbar-nav glyphicon glyphicon-align-justify btn-menu toggle navbar-brand navbar-right" data-toggle="collapse-slide-right" data-target="#sidebar-right-wrapper">
                            <i class="fa fa-bars"></i>
                        </a>
                    </div> <!-- /navbar-header -->
                </div> <!-- /container-fluid -->
            </nav><!-- /navbar -->
            
            <div id="sidebar-left-wrapper" aria-expanded="true">
                <div id="userprofile">
                    <!--
                    <p><?php echo $userUsername; ?></p>
                    <ul class="nav">
                        <li>Posts: <?php echo $userUsername; ?></li>
                        <li>Likes: <?php echo $userUsername; ?></li>
                        <li>Followers: <?php echo $userUsername; ?></li>
                        <li>Following: <?php echo $userUsername; ?></li>
                    </ul>
                    -->
                </div><!-- /userprofile -->
                <div id="trendingwords">
                    <h3>Trending words:</h3>
                    <?php require 'php/trending.php';
                    ?>
                </div><!-- /trendingwords -->
            </div><!-- /sidebar-left-wrapper -->
            
            <!-- Page content -->
            <div id="page-content-wrapper">
                <div class="jumbotron">
                    <div class="container-fluid">
                        <!-- MAIN CONTENT -->
                        <div class="postWrapper">
                            <!-- 
                            
                                POST FORM TO BE PLACED HERE 
                            
                            -->
                            
                            <div class="postContent">
                                <div class="userSection">
                                <span class="timeStamp">timestamp</span>
                                <h3>Username</h3>
                                </div>
                                <div class="postSection">
                                <h2>Word Word Word</h2>
                                </div>
                                <div class="reactionSection">
                                    <button class="like">Like</button>
                                    <button class="dislike">Dislike</button>
                                </div>
                            </div>
                        </div>
                        
                    </div><!-- /container-fluid -->
                </div> <!-- page-content -->
            </div><!-- /page-content-wrapper -->
            
            <div id="sidebar-right-wrapper" class="float-right" aria-expanded="true">
                <div id="previewprofile">
                    <!--
                    <p><?php echo $previewUsername; ?></p>
                    <ul class="nav">
                        <li>Posts: <?php echo $previewUsername; ?></li>
                        <li>Likes: <?php echo $previewUsername; ?></li>
                        <li>Followers: <?php echo $previewUsername; ?></li>
                        <li>Following: <?php echo $previewUsername; ?></li>
                    </ul>
                    -->
                </div><!-- /previewprofile -->
                <div id="previewposts">
                    <h3>Posts:</h3>
                </div><!-- /previewprofile -->
            </div><!-- /sidebar-left-wrapper -->
            
        </div><!-- /wrapper -->
        
        <!-- LOGIN MODAL WINDOW -->
        <div id="login_window" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Log-in</h4>
                    </div>
                    <div class="modal-body">
                        <form id="login">
                            <div class="form-group">
                                <input class="form-control" type="text" id="username" placeholder="Username">
                            </div>
                            <div class="form-group">
                                <input class="form-control" type="password" id="password" placeholder="Password">
                            </div>
                            <input type="submit" class="btn btn-default" value="Log-in">
                            <button type="button" class="btn btn-default right" data-dismiss="modal">Cancel</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://use.fontawesome.com/e0490efbcf.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/homepage.js"></script>

    </body>

</html>
